# Robotics 1 Fall 2019 Final Project
## Team: Noah Ashton and Dev Rangarajan
## Professor Amar Khoukhi

Project: DobotScribe, a program that allows the dobot to write letters using inverse kinematics and a webcam.

Setup: Launch a RobotRaconteur/pydobot server node (using our provided files), and make sure the dobot is connected.
To run the project load all code files into the same folder and run main.m
